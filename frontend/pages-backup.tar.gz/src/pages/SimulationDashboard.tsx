import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, ReferenceLine,
  BarChart, Bar, Cell, Legend
} from 'recharts';
import { ArrowLeft, Share2, Download, Info, AlertTriangle, Activity, Zap, Shield, Target, FlaskConical, ChevronRight, CheckCircle2, User, MapPin } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { useNavigate } from 'react-router-dom';
import { TREATMENT_PLANS, generateDistributionData } from '../data/mockData';

export function SimulationDashboard() {
  const navigate = useNavigate();
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [showComparison, setShowComparison] = useState(false);
  
  const selectedPlan = TREATMENT_PLANS.find(p => p.id === selectedPlanId);

  // Generate distribution data for the selected plan (mocking slight variations)
  const distributionData = selectedPlan ? generateDistributionData(
    selectedPlan.simulation.survival10Year > 85 ? 80 : 70, // Mean
    15 // Std Dev
  ) : [];

  const handlePlanSelect = (id: string) => {
    setSelectedPlanId(id === selectedPlanId ? null : id);
    // Scroll to results
    if (id !== selectedPlanId) {
      setTimeout(() => {
        document.getElementById('simulation-results')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-20 shadow-sm backdrop-blur bg-white/90">
        <div className="container mx-auto px-4 py-4">
           <div className="flex items-center justify-between mb-2">
             <div className="flex items-center gap-2">
               <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
                 <ArrowLeft className="h-4 w-4 mr-2" /> Back
               </Button>
               <h1 className="text-xl md:text-2xl font-bold text-slate-900">Treatment Plan Outcomes Simulator</h1>
             </div>
             <div className="hidden md:flex gap-2">
               <Button variant="outline" size="sm"><Share2 className="h-4 w-4 mr-2" /> Share Report</Button>
               <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2" /> Export PDF</Button>
             </div>
           </div>
           
           {/* Profile Summary */}
           <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600 ml-2 md:ml-12 bg-slate-50 p-2 rounded-md border border-slate-100 inline-flex">
              <span className="flex items-center gap-1 font-medium text-slate-900"><User className="h-3 w-3" /> Profile:</span>
              <span>45 yrs</span>
              <span className="text-slate-300">|</span>
              <span>Stage IIA</span>
              <span className="text-slate-300">|</span>
              <span className="text-[#E91E63] font-medium">HER2+</span>
              <span className="text-slate-300">|</span>
              <span>ER+/PR+</span>
              <Button variant="link" className="h-auto p-0 text-[#00BFB3] text-xs ml-2" onClick={() => navigate('/profile')}>Edit</Button>
           </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-8">
        
        {/* Treatment Plans Grid */}
        <section>
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Select a Treatment Plan to Simulate</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TREATMENT_PLANS.map((plan) => (
              <motion.div
                key={plan.id}
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Card 
                  className={`cursor-pointer transition-all border-2 relative overflow-hidden ${selectedPlanId === plan.id ? 'border-[#E91E63] ring-4 ring-pink-50 shadow-xl' : 'border-transparent hover:border-slate-200 shadow-md'}`}
                  onClick={() => handlePlanSelect(plan.id)}
                >
                  {plan.recommended && (
                    <div className="absolute top-0 right-0 bg-[#E91E63] text-white text-xs font-bold px-3 py-1 rounded-bl-lg shadow-sm">
                      Recommended
                    </div>
                  )}
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`p-3 rounded-full ${selectedPlanId === plan.id ? 'bg-[#E91E63] text-white' : 'bg-slate-100 text-slate-600'}`}>
                        {plan.icon === 'activity' && <Activity className="h-6 w-6" />}
                        {plan.icon === 'shield' && <Shield className="h-6 w-6" />}
                        {plan.icon === 'zap' && <Zap className="h-6 w-6" />}
                        {plan.icon === 'target' && <Target className="h-6 w-6" />}
                        {plan.icon === 'flask' && <FlaskConical className="h-6 w-6" />}
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{plan.name}</h3>
                    <p className="text-slate-500 text-sm mb-4 min-h-[40px]">{plan.description}</p>
                    
                    <Button 
                      className={`w-full ${selectedPlanId === plan.id ? 'bg-[#E91E63] hover:bg-[#D81B60]' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'}`}
                    >
                      {selectedPlanId === plan.id ? 'Viewing Results' : 'View Simulation Results'}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Simulation Results Panel */}
        <AnimatePresence>
          {selectedPlan && (
            <motion.section 
              id="simulation-results"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-6 overflow-hidden"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="h-8 w-1 bg-[#E91E63] rounded-full"></div>
                <h2 className="text-2xl font-bold text-slate-900">Simulation Results: <span className="text-[#E91E63]">{selectedPlan.name}</span></h2>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Section A: Outcome Distribution */}
                <Card className="lg:col-span-2 shadow-lg border-t-4 border-t-[#00BFB3]">
                  <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                      <span>10-Year Disease-Free Survival Probability</span>
                      <Badge variant="outline" className="text-[#00BFB3] border-[#00BFB3] bg-teal-50">High Confidence</Badge>
                    </CardTitle>
                    <CardDescription>
                      Based on 5,000 Monte Carlo simulations using PubMed clinical data tailored to your profile.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                     <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={distributionData} margin={{ top: 20, right: 0, left: 0, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorY" x1="0" y1="0" x2="1" y2="0">
                            <stop offset="10%" stopColor="#ef4444" stopOpacity={0.6} /> {/* Red/Poor */}
                            <stop offset="50%" stopColor="#eab308" stopOpacity={0.6} /> {/* Yellow/Avg */}
                            <stop offset="90%" stopColor="#22c55e" stopOpacity={0.6} /> {/* Green/Good */}
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="x" 
                          label={{ value: 'Survival Probability (%)', position: 'insideBottom', offset: -5 }} 
                          tickFormatter={(val) => val.toFixed(0)} 
                          type="number"
                          domain={['dataMin', 'dataMax']}
                        />
                        <YAxis hide />
                        <RechartsTooltip 
                          content={({ active, payload }) => {
                             if (active && payload && payload.length) {
                               return (
                                 <div className="bg-white p-2 border shadow-sm rounded-md text-xs">
                                   <p className="font-bold">Probability: {payload[0].payload.x.toFixed(1)}%</p>
                                   <p>Likelihood: High</p>
                                 </div>
                               );
                             }
                             return null;
                          }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="y" 
                          stroke="#00BFB3" 
                          strokeWidth={3}
                          fill="url(#colorY)" 
                          fillOpacity={1} 
                        />
                        <ReferenceLine x={selectedPlan.simulation.survival10Year} stroke="#E91E63" strokeDasharray="3 3" label={{ value: `Est. ${selectedPlan.simulation.survival10Year}%`, fill: '#E91E63', fontWeight: 'bold' }} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                  <div className="px-6 pb-6 grid grid-cols-3 gap-4 text-center">
                    <div className="p-4 bg-slate-50 rounded-lg">
                       <div className="text-3xl font-bold text-[#00BFB3]">{selectedPlan.simulation.survival10Year}%</div>
                       <div className="text-xs text-slate-500 uppercase font-bold tracking-wide mt-1">10-Year Survival</div>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-lg">
                       <div className="text-3xl font-bold text-slate-700">{selectedPlan.simulation.recurrence5Year}%</div>
                       <div className="text-xs text-slate-500 uppercase font-bold tracking-wide mt-1">5-Year Recurrence Free</div>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-lg">
                       <div className="text-3xl font-bold text-slate-700">{selectedPlan.simulation.qalys}</div>
                       <div className="text-xs text-slate-500 uppercase font-bold tracking-wide mt-1">Est. QALYs</div>
                    </div>
                  </div>
                </Card>

                {/* Section C: Complications & Side Effects */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Projected Complications</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                       <div className="space-y-2">
                          <h4 className="text-sm font-semibold text-slate-900">Acute (Short-term)</h4>
                          {selectedPlan.simulation.toxicities.acute.map((tox, i) => (
                             <div key={i} className="flex justify-between items-center text-sm">
                                <span className="text-slate-600">{tox.name}</span>
                                <span className="font-medium text-amber-600">{tox.value}%</span>
                             </div>
                          ))}
                       </div>
                       <div className="w-full h-px bg-slate-100 my-2"></div>
                       <div className="space-y-2">
                          <h4 className="text-sm font-semibold text-slate-900">Long-term Effects</h4>
                          {selectedPlan.simulation.toxicities.longTerm.map((tox, i) => (
                             <div key={i} className="flex justify-between items-center text-sm">
                                <span className="text-slate-600">{tox.name}</span>
                                <span className="font-medium text-slate-900">{tox.value}{tox.max ? '/10' : '%'}</span>
                             </div>
                          ))}
                       </div>
                    </CardContent>
                  </Card>

                  {/* Section D: Cost Projection */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Financial Impact (10-Year)</CardTitle>
                    </CardHeader>
                    <CardContent>
                       <div className="mb-4">
                         <div className="text-3xl font-bold text-slate-900">${selectedPlan.simulation.costTotal.toLocaleString()}</div>
                         <div className="text-sm text-slate-500">Total Estimated Cost</div>
                       </div>
                       <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                             <span className="flex items-center gap-2"><div className="w-3 h-3 bg-slate-200 rounded-full"></div> Insurance Covers</span>
                             <span className="font-medium text-slate-900">${(selectedPlan.simulation.costTotal - selectedPlan.simulation.costPocket).toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                             <span className="flex items-center gap-2"><div className="w-3 h-3 bg-[#E91E63] rounded-full"></div> Your Out-of-Pocket</span>
                             <span className="font-bold text-[#E91E63]">${selectedPlan.simulation.costPocket.toLocaleString()}</span>
                          </div>
                       </div>
                       <div className="mt-4 h-3 flex w-full rounded-full overflow-hidden">
                          <div style={{ width: `${(1 - selectedPlan.simulation.costPocket/selectedPlan.simulation.costTotal)*100}%` }} className="bg-slate-200 h-full"></div>
                          <div style={{ width: `${(selectedPlan.simulation.costPocket/selectedPlan.simulation.costTotal)*100}%` }} className="bg-[#E91E63] h-full"></div>
                       </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Section E: Variance Decomposition */}
                <Card className="lg:col-span-3">
                  <CardHeader>
                     <CardTitle>What Drives Your Outcome?</CardTitle>
                     <CardDescription>Understanding which factors have the biggest impact on your success rate.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                         <BarChart 
                            layout="vertical" 
                            data={[
                               { name: 'Tumor Stage (Fixed)', value: 28, fill: '#cbd5e1' },
                               { name: 'Receptor Status (Fixed)', value: 35, fill: '#cbd5e1' },
                               { name: 'Treatment Choice (Modifiable)', value: 23, fill: '#E91E63' },
                               { name: 'Hospital Quality (Modifiable)', value: 14, fill: '#00BFB3' }
                            ]}
                            margin={{ left: 120 }}
                         >
                            <XAxis type="number" hide />
                            <YAxis dataKey="name" type="category" width={150} tick={{ fontSize: 12 }} />
                            <RechartsTooltip />
                            <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20} />
                         </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-4 p-4 bg-teal-50 border border-teal-100 rounded-lg flex items-start gap-3">
                       <Info className="h-5 w-5 text-[#00BFB3] mt-0.5" />
                       <p className="text-sm text-teal-800">
                         <strong>Key Insight:</strong> Your choice of hospital accounts for <strong>14%</strong> of the variance in outcomes. 
                         Choosing a high-volume center can significantly improve your long-term prognosis.
                       </p>
                    </div>
                  </CardContent>
                </Card>

              </div>

              {/* Find Centers CTA */}
              <div className="mt-12 bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-8 md:p-12 text-center md:text-left relative overflow-hidden text-white shadow-2xl">
                 <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                 <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="space-y-4 max-w-2xl">
                       <h2 className="text-3xl font-bold">Ready to Choose a Treatment Center?</h2>
                       <p className="text-slate-300 text-lg">
                         Now that you've explored the clinical outcomes, find the best hospitals near you that specialize in <span className="text-[#00BFB3] font-bold">{selectedPlan.name}</span>.
                       </p>
                    </div>
                    <Button 
                      size="lg" 
                      className="bg-gradient-to-r from-[#00BFB3] to-[#00A69C] hover:from-[#00A69C] hover:to-[#008f85] text-white font-bold text-lg px-8 py-6 h-auto shadow-lg shadow-teal-500/20 whitespace-nowrap"
                      onClick={() => navigate('/find-centers')}
                    >
                      Find Treatment Centers <MapPin className="ml-2 h-5 w-5" />
                    </Button>
                 </div>
              </div>

            </motion.section>
          )}
        </AnimatePresence>

        {!selectedPlan && (
           <div className="text-center py-20 text-slate-400">
             <Activity className="h-16 w-16 mx-auto mb-4 opacity-20" />
             <p className="text-lg">Select a treatment plan above to view personalized simulation results.</p>
           </div>
        )}

      </div>
    </div>
  );
}
